# Introduction to Amazon DynamoDB

© 2018 Amazon Web Services, Inc. and its affiliates. All rights reserved. This work may not be reproduced or redistributed, in whole or in part, without prior written permission from Amazon Web Services, Inc. Commercial copying, lending, or selling is prohibited.

Errors or corrections? Email us at aws-course-feedback@amazon.com.

Other questions? Contact us at https://aws.amazon.com/contact-us/aws-training/

## Lab Overview
**Amazon DynamoDB** is a fast and flexible NoSQL database service for all applications that need consistent, single-digit millisecond latency at any scale. It is a **fully managed** database and supports both document and key-value data models. Its flexible data model and reliable performance make it a great fit for mobile, web, gaming, ad-tech, IoT, and many other applications.

In this lab, you will create a table in Amazon DynamoDB to store information about a music library. You will then query the music library and, finally, delete the DynamoDB table.

## Topics covered
In this lab, you will:

* Create an Amazon DynamoDB table
* Enter data into an Amazon DynamoDB table
* Query an Amazon DynamoDB table
* Delete an Amazon DynamoDB table

## Task 1: Create a New Table
In this task, you will create a new table in DynamoDB named _Music_. Each table requires a Primary Key that is used to partition data across DynamoDB servers. A table can also have a Sort Key. The combination of Primary Key and Sort Key uniquely identifies each item in a DynamoDB table.

1. In the AWS Management Console, click **Services**, then click **DynamoDB**.
2. Click **Create table**.
3. For **Table name**, type: `Music`
4. For **Primary key**, type `Artist` and leave **String** selected.
5. Select **Add sort key**, then in the new field type `Song` and leave **String** selected.

  Your table will use default settings for indexes and provisioned capacity.

6. Click **Create**.

  The table will be created in less than a minute.

## Task 2: Add Data
In this task, you will add data to the _Music_ table. A **table** is a collection of data on a particular topic.

Each table contains multiple **items**. An item is a group of attributes that is uniquely identifiable among all of the other items. Items in DynamoDB are similar in many ways to rows in other database systems. In DynamoDB, there is no limit to the number of items you can store in a table.

Each item is composed of one or more **attributes**. An attribute is a fundamental data element, something that does not need to be broken down any further. For example, an item in a `Music` table contains attributes such as Song and Artist. Attributes in DynamoDB are similar columns in other database systems, but each item (row) can have different attributes (columns).

When you write an item to a DynamoDB table, only the Primary Key and Sort Key (if used) are required. Other than these fields, the table does not require a schema. This means that you can add attributes to one item that may be different to the attributes on other items.

1. Click the **Items** tab, then click **Create item**.

  > If the table is still being created, refresh the web page to display the Items tab.

2. For **Artist** String, type: `Pink Floyd`

3. For **Song** String, type: `Money`

  These are the only required attributes, but you will now add additional attributes.

4. To create an additional attribute, click the plus sign to the left of _Song_, then click **Append**.

  ![](https://s3-eu-west-1.amazonaws.com/aws-managed-dbs-workshop/append.png)

5. In the drop-down list, select **String**.

  A new attribute row will be added.

6. For the new attribute, enter:
  * In **FIELD**, type: `Album`
  * In **VALUE**, type: `The Dark Side of the Moon`

7. Add another new attribute by clicking the plus sign to the left _Album_, then click **Append**.

8. In the drop-down list select **Number**.

  A new _number_ attribute will be added.

9. For the new attribute, enter:
  * In **FIELD**, type: `Year`
  * In **VALUE**, type: `1973`

10. Click **Save** to store the new Item with its four attributes.

  The item will appear in the console.

11. Now **create a second Item**, using these attributes:

  |Attribute Name|Attribute Type|Attribute Value|
  |--------------|--------------|---------------|
  |Artist|String|John Lennon|
  |Song|String|Imagine|
  |Album|String|Imagine|
  |Year|Number|1971|
  |Genre|String	|Soft rock|

  Note that this item has an additional attribute called _genre_. This is an example of each item being capable of having different attributes without having to pre-define a table schema.

12. **Create a third Item**, using these attributes:

  |Attribute Name|Attribute Type|Attribute Value|
  |--------------|--------------|---------------|
  |Artist|String|Psy|
  |Song|String|Gangnam Style|
  |Album|String|Psy 6 (Six Rules), Part 1|
  |Year|Number|2011|
  |LengthSeconds|Number|219|

  Once again, this item has a new LengthSeconds attribute identifying the length of the song. This demonstrates the flexibility of a NoSQL database.

There are also faster ways to load data into DynamoDB, such as using AWS Data Pipeline, programmatically loading data or using one of the free tools available on the Internet.

## Task 3: Modify an Existing Item
You now notice that there is an error in your data. In this task, you will modify an existing item.

1. Click **Psy**.

2. Change the **Year** from _2011_ to _2012_.

3. Click **Save**.

The item is now updated.

## Task 4: Query the Table
There are two ways to query a DynamoDB table: _Query_ and _Scan_.

A **query** operation finds items based on Primary Key and optionally Sort Key. It is fully indexed, so it runs very fast.

1. Click the drop-down list showing **Scan** (located below the _Create item_ button) and change it to **Query**.
  
  Fields for the Partition Key (which is the same as Primary Key) and Sort Key are now displayed.

2. Enter these details:
  * Partition key: `Psy`
  * Sort key: `Gangnam Style`
 
3. Click **Start search**. (You might need to scroll down to see it.)

  The song quickly appears in the list. A _query_ is the most efficient way to retrieve data from a DynamoDB table.

  Alternatively, you can _scan_ for an item. This involves looking through _every item in a table_, so it is less efficient and can take significant time for larger tables.

4. Click the drop-down list showing **Query** and change it back to **Scan**.

5. Click **Add filter**, then:

  ![](https://s3-eu-west-1.amazonaws.com/aws-managed-dbs-workshop/addfilter.png)
  
  * For **Enter attribute**, type: `Year`
  * Change _String_ to _Number_
  * For **Enter value**, type: `1971`
  * Click **Start search**

Only the song released in 1971 is displayed.

## Task 5: Delete the Table
In this task, you will delete the _Music_ table, which will also delete all the data in the table.

1. Click **Delete table**. On the confirmation panel, click **Delete**.

The table will be deleted.

## Conclusion
Congratulations! You have now successfully learned how to:

* Create an Amazon DynamoDB table
* Enter data into an Amazon DynamoDB table
* Query an Amazon DynamoDB table
* Delete an Amazon DynamoDB table

## Additional Resources
* [DynamoDB documentation](http://aws.amazon.com/documentation/dynamodb)
* [AWS Training and Certification](http://aws.amazon.com/training)
